#!/usr/bin/env python3
"""
Print Cafe - Windows Host Print Agent
Background Python service that enumerates installed Windows printers,
sends heartbeats to the web backend, polls for queued print jobs,
applies PDF/image settings (page ranges, copies, orientation),
and dispatches print jobs to the Windows Print Spooler.
"""

import os
import sys
import time
import json
import tempfile
import argparse
import subprocess
import requests
from pathlib import Path

# Try importing Windows printing & PDF libraries
try:
    import win32print
    import win32api
    import win32ui
    import win32con
    HAS_WIN32 = True
except ImportError:
    HAS_WIN32 = False

try:
    from pypdf import PdfReader, PdfWriter
    HAS_PYPDF = True
except ImportError:
    HAS_PYPDF = False

try:
    from PIL import Image, ImageWin
    HAS_PIL = True
except ImportError:
    HAS_PIL = False

# Default Config
DEFAULT_SERVER_URL = "http://localhost/PrintCafe app"
VIRTUAL_PRINTER_KEYWORDS = ["pdf", "onenote", "xps", "anydesk", "fax", "microsoft print to pdf", "adobe pdf"]

class HostPrintAgent:
    def __init__(self, server_url=DEFAULT_SERVER_URL, host_uuid=None):
        self.server_url = server_url.rstrip("/")
        self.host_uuid = host_uuid
        self.running = False
        self.active_printer = None

    def get_installed_printers(self):
        """Enumerate installed Windows printers using win32print or PowerShell fallback"""
        printers = []
        if HAS_WIN32:
            try:
                flags = win32print.PRINTER_ENUM_LOCAL | win32print.PRINTER_ENUM_CONNECTIONS
                enum_printers = win32print.EnumPrinters(flags)
                for p in enum_printers:
                    p_name = p[2]
                    is_virtual = any(k in p_name.lower() for k in VIRTUAL_PRINTER_KEYWORDS)
                    printers.append({
                        "name": p_name,
                        "system_name": p_name,
                        "is_virtual": is_virtual
                    })
            except Exception as e:
                print(f"[Agent] Error enumerating win32 printers: {e}")

        if not printers:
            # PowerShell Fallback
            try:
                cmd = ["powershell", "-Command", "Get-Printer | Select-Object -Property Name, Type | ConvertTo-Json"]
                output = subprocess.check_output(cmd, text=True)
                data = json.loads(output)
                if isinstance(data, dict):
                    data = [data]
                for item in data:
                    p_name = item.get("Name", "")
                    if p_name:
                        is_virtual = any(k in p_name.lower() for k in VIRTUAL_PRINTER_KEYWORDS)
                        printers.append({
                            "name": p_name,
                            "system_name": p_name,
                            "is_virtual": is_virtual
                        })
            except Exception as e:
                print(f"[Agent] PowerShell printer fallback failed: {e}")

        return printers

    def send_heartbeat(self):
        """Send heartbeat and printer list to backend server"""
        url = f"{self.server_url}/api/host_heartbeat.php"
        printers = self.get_installed_printers()
        payload = {
            "host_uuid": self.host_uuid or "",
            "agent_version": "1.0.0",
            "printers": printers
        }
        try:
            res = requests.post(url, json=payload, timeout=5)
            if res.status_code == 200:
                data = res.json()
                if data.get("success"):
                    if not self.host_uuid:
                        self.host_uuid = data.get("host_uuid")
                    return True
        except Exception as e:
            print(f"[Agent] Heartbeat error: {e}")
        return False

    def poll_job(self):
        """Poll server for next QUEUED job"""
        url = f"{self.server_url}/api/agent_jobs.php?host_id={self.host_uuid or ''}"
        try:
            res = requests.get(url, timeout=5)
            if res.status_code == 200:
                data = res.json()
                if data.get("success") and data.get("has_job"):
                    return data.get("job")
        except Exception as e:
            print(f"[Agent] Job poll error: {e}")
        return None

    def update_job_status(self, job_uuid, status, message=""):
        """Report status updates to web backend"""
        url = f"{self.server_url}/api/agent_update_job.php"
        payload = {
            "job_id": job_uuid,
            "status": status,
            "message": message
        }
        try:
            requests.post(url, json=payload, timeout=5)
        except Exception as e:
            print(f"[Agent] Status update failed: {e}")

    def process_pdf_pages(self, src_path, page_selection_type, page_from, page_to, custom_pages):
        """Extract/crop requested pages using PyPDF"""
        if not HAS_PYPDF:
            return src_path

        try:
            reader = PdfReader(src_path)
            total_pages = len(reader.pages)
            writer = PdfWriter()

            pages_to_extract = []
            if page_selection_type == "range":
                start = max(1, page_from) - 1
                end = min(total_pages, page_to)
                pages_to_extract = list(range(start, end))
            elif page_selection_type == "custom" and custom_pages:
                parts = custom_pages.split(",")
                for part in parts:
                    part = part.strip()
                    if "-" in part:
                        try:
                            s, e = part.split("-", 1)
                            for pnum in range(int(s), int(e) + 1):
                                if 1 <= pnum <= total_pages:
                                    pages_to_extract.append(pnum - 1)
                        except ValueError:
                            pass
                    else:
                        try:
                            pnum = int(part)
                            if 1 <= pnum <= total_pages:
                                pages_to_extract.append(pnum - 1)
                        except ValueError:
                            pass
            else:
                return src_path

            if not pages_to_extract:
                return src_path

            for idx in pages_to_extract:
                writer.add_page(reader.pages[idx])

            tmp_fd, tmp_path = tempfile.mkstemp(suffix="_print.pdf")
            os.close(tmp_fd)
            with open(tmp_path, "wb") as f:
                writer.write(f)

            return tmp_path
        except Exception as e:
            print(f"[Agent] PyPDF extraction error: {e}")
            return src_path

    def execute_print_job(self, job):
        """Execute print job on target Windows Printer Spooler"""
        job_uuid = job.get("job_uuid")
        file_path = job.get("file_path")
        printer_name = job.get("printer_name") or job.get("printer_system_name")
        copies = int(job.get("copies", 1))

        print(f"\n[Agent] Processing Print Job #{job_uuid} -> Printer: {printer_name}")
        self.update_job_status(job_uuid, "PROCESSING", "Agent preparing document & print parameters...")

        if not file_path or not os.path.exists(file_path):
            # Try resolving path relative to server root
            resolved_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), file_path.lstrip("/\\"))
            if os.path.exists(resolved_path):
                file_path = resolved_path
            else:
                self.update_job_status(job_uuid, "FAILED", f"Source file not found on host disk: {file_path}")
                return

        # Process page range if PDF
        target_print_file = file_path
        if job.get("file_type") == "pdf":
            target_print_file = self.process_pdf_pages(
                file_path,
                job.get("page_selection_type"),
                int(job.get("page_from", 1)),
                int(job.get("page_to", 1)),
                job.get("custom_pages", "")
            )

        self.update_job_status(job_uuid, "SENDING_TO_PRINTER", "Sending job to Windows Spooler...")

        try:
            # Print using PyWin32 GDI or PowerShell PrintTo
            success = self.spool_to_windows_printer(target_print_file, printer_name, copies)
            if success:
                self.update_job_status(job_uuid, "PRINTING", "Document sent to printer.")
                time.sleep(2) # Give spooler time to process
                self.update_job_status(job_uuid, "COMPLETED", "Print job completed successfully.")
                print(f"[Agent] Successfully printed job #{job_uuid}")
            else:
                self.update_job_status(job_uuid, "FAILED", "Windows printer spooling failed.")
        except Exception as e:
            self.update_job_status(job_uuid, "FAILED", f"Error during printing: {str(e)}")
        finally:
            # Clean temporary extracted PDF if created
            if target_print_file != file_path and os.path.exists(target_print_file):
                try:
                    os.remove(target_print_file)
                except Exception:
                    pass

    def spool_to_windows_printer(self, file_path, printer_name, copies=1):
        """Spool print file to Windows Spooler using ShellExecute or PowerShell"""
        ext = os.path.splitext(file_path)[1].lower()

        # Method 1: win32api ShellExecute "printto"
        if HAS_WIN32 and printer_name:
            try:
                for _ in range(copies):
                    win32api.ShellExecute(0, "printto", file_path, f'"{printer_name}"', ".", 0)
                return True
            except Exception as e:
                print(f"[Agent] ShellExecute printto warning: {e}")

        # Method 2: PowerShell Start-Process PrintTo
        try:
            for _ in range(copies):
                ps_cmd = f'Start-Process -FilePath "{file_path}" -Verb PrintTo -ArgumentList "{printer_name}" -WindowStyle Hidden'
                subprocess.run(["powershell", "-Command", ps_cmd], check=True)
            return True
        except Exception as e:
            print(f"[Agent] PowerShell print error: {e}")

        return False

    def start(self):
        """Main agent execution loop"""
        self.running = True
        print("=" * 60)
        print("   PRINT CAFE - WINDOWS HOST PRINT AGENT v1.0.0")
        print(f"   Connecting to Server: {self.server_url}")
        print("=" * 60)

        # Initial Heartbeat
        if self.send_heartbeat():
            print(f"[Agent] Connected! Host UUID: {self.host_uuid}")
        else:
            print("[Agent] Initial connection ping failed. Will keep retrying...")

        last_hb = 0
        try:
            while self.running:
                now = time.time()
                # Heartbeat every 5s
                if now - last_hb >= 5:
                    self.send_heartbeat()
                    last_hb = now

                # Poll for job
                job = self.poll_job()
                if job:
                    self.execute_print_job(job)
                else:
                    time.sleep(2)
        except KeyboardInterrupt:
            print("\n[Agent] Shutting down agent...")
            self.running = False

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Print Cafe Host Agent")
    parser.add_argument("--url", default=DEFAULT_SERVER_URL, help="Print Cafe Server URL")
    parser.add_argument("--host", default=None, help="Host UUID")
    args = parser.parse_args()

    agent = HostPrintAgent(server_url=args.url, host_uuid=args.host)
    agent.start()
